# Camera plan (all shots end at rest; beat times come from sentence_times.json)

Frame at an 80 degree vertical field of view, 9:16: width = 0.93 x distance, height = 1.68 x distance.
Every move uses `warpU` (monotone cubic time warp, zero speed at first and last key) so the camera reaches each subject as it is named.

| # | Time | World | Camera path | Move | Foreground (blurred) / Midground / Background | In-world labels |
|---|---|---|---|---|---|---|
| 1 | 0.00-3.32 | Lecture hall | wide (0.9,2.0,2.9) -> (0,1.8,0.1) | push ~45% | stool at lens right / lecturer / chandelier, windows, chalkboard | banner "STRANGE FACTS OF THE HUMAN BODY", chalkboard, lectern nameplate |
| 2 | 3.32-6.32 | Eye-exam room | (-1.9,1.5,4.2) -> (0.4,1.7,0.2) | sideways track + push, nose slides out of frame on "nose" (5.5 s) | giant nose model at lens / reader / eye chart, wall plaque | "EYE EXAM ROOM", eye chart |
| 3 | 6.32-10.48 | Torso lab | (-0.8,1.2,2.9) -> (1.1,2.7,1.4) | crane up | drip pole / torso tray with drifting organs, character / dome lamp, tiled wall | "ORGANS (SHIFTING)" |
| 4 | 10.48-16.88 | Night street, bench | (-2.4,4.4,5.4) -> (-0.6,1.5,1.8) | crane down | barrel / lone character, empty bench, lamp / lit facades, stars | "BUS STOP" |
| 5 | 16.88-19.21 | Microbe lab | (-3.0,1.7,2.4) -> (3.0,1.7,2.4) | sideways track, one dish per word | flask at lens / three dishes, character / shelf-tiled wall | cards pop on the words: MITES 17.3 s, FUNGUS 17.85 s, BACTERIA 18.5 s |
| 6 | 19.21-25.65 | Gym | (-2.0,1.9,3.0) -> (1.8,2.0,0.8) | track then push on the dial | kettlebell / lifter with barbell / brick wall | FORCE-O-METER dial: needle sweeps to 60% on "60%" (20.9-22.3 s), pin locks red on "protects you" (24.1 s) |
| 7 | 25.65-31.00 | Workshop | (-3.2,1.9,3.4) -> (1.6,1.9,2.2) | sideways track | crate / rope-muscle rig, bone bench / brick wall | "100% POWER" board; strands tear at 29.05 s, bone snaps at 30.55 s |
| 8 | 31.00-35.45 | Night street, car | (-3.6,1.5,4.0) -> (1.2,3.0,2.8) | push then crane up | barrel / car and lifter / lamps, facades | car corner rises from 31.85 s |
| 9 | 35.45-38.30 | Lecture hall (side view) | (5.4,2.0,1.8) -> (3.9,1.8,-0.5) | push | benches / lecturer, lever, brain / chalkboard | "OVERRIDE" plaque; lever pulled 36.55 s, brain lights up |

Cuts: 0.4 s dip to cream at every location change; soft fade at the very end. No captions, no floating labels.
