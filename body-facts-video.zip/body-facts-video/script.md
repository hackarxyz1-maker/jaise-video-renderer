# Voice-over (user's own recording, trimmed to 38.3 s; "follow for more" removed)

here are the most unusual facts about our human bodies
just like your vision is filtering out your nose right now
your brain also blocks the feeling of your organs shifting inside of you
now if you're ever feeling lonely you should know that our bodies carry 2 to 5 lbs of built-in company
like mites fungus and bacteria
no matter how hard you try you can only use about 60% of your full strength and this actually protects you
because if you could use 100% you'd end up tearing your own muscles or breaking your own bones
so if someone lifts a car or shows superhuman strength in a dire situation
it's their brain overriding this rule for survival

Fact-check notes (wording left as recorded): the "2 to 5 lbs" figure is the older estimate; a 2016 revision puts bacteria at roughly 0.2 kg. The 60% figure is a loose estimate. "Lifts a car" usually means lifting one corner. The nose and organ claims were not verified.
