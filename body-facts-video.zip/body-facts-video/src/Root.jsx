import React from 'react';
import { Composition } from 'remotion';
import { Full } from './Full.jsx';
import { FRAMES, FPS } from './camera.js';

export const Root = () => <Composition id="BodyFacts" component={Full} durationInFrames={FRAMES} fps={FPS} width={720} height={1280} />;
