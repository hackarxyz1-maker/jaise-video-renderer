import * as THREE from 'three';
import { WORLDS } from './worlds.jsx';

export const FPS = 30;
export const DURATION = 38.3;
export const FRAMES = Math.round(DURATION * FPS); // 1149

// Shot cuts come from real sentence ends found in the voice-over (see sentence_times.json)
export const CUTS = [0, 3.32, 6.32, 10.48, 16.88, 19.21, 25.65, 31.0, 35.45, DURATION];

// shot -> which world (index into WORLDS; the hall is world 0 and is reused for shot 9)
export const SHOT_WORLD = [0, 1, 2, 3, 4, 5, 6, 7, 0];

// monotone cubic time warp: beat times T -> path position 0..1 (zero speed at first and last key)
export function warpU(T, t) {
  const n = T.length; if (t <= T[0]) return 0; if (t >= T[n - 1]) return 1;
  const sec = []; for (let i = 0; i < n - 1; i++) sec.push((1 / (n - 1)) / (T[i + 1] - T[i]));
  const m = [0]; for (let i = 1; i < n - 1; i++) m.push(2 * sec[i - 1] * sec[i] / (sec[i - 1] + sec[i])); m.push(0);
  let i = 0; while (t > T[i + 1]) i++;
  const h = T[i + 1] - T[i], x = (t - T[i]) / h, x2 = x * x, x3 = x2 * x;
  return (2 * x3 - 3 * x2 + 1) * (i / (n - 1)) + (x3 - 2 * x2 + x) * h * m[i] + (-2 * x3 + 3 * x2) * ((i + 1) / (n - 1)) + (x3 - x2) * h * m[i + 1];
}

const o = (i) => WORLDS[SHOT_WORLD[i]].ox;
// each shot: keys [pos, look] (local to the world offset) and beat times T (one per key)
const RAW = [
  { T: [0, 1.7, 3.32], k: [[[0.9, 2.0, 2.9], [0, 1.5, -3.2]], [[0.4, 1.9, 1.5], [0, 1.5, -2.6]], [[0, 1.8, 0.1], [0, 1.5, -2.4]]] },
  { T: [3.32, 5.5, 6.32], k: [[[-1.9, 1.5, 4.2], [0.3, 1.4, -3]], [[-0.2, 1.6, 2.0], [0.5, 1.5, -3.6]], [[0.4, 1.7, 0.2], [0.9, 1.6, -4.6]]] },
  { T: [6.32, 7.9, 10.48], k: [[[-0.8, 1.2, 2.9], [0.2, 1.4, -2.7]], [[0.1, 1.9, 1.9], [0.1, 1.7, -2.7]], [[1.1, 2.7, 1.4], [0.6, 1.7, -2.5]]] },
  { T: [10.48, 12.3, 16.88], k: [[[-2.4, 4.4, 5.4], [0, 0.9, -2.4]], [[-1.8, 2.8, 4.4], [-0.4, 1.1, -2.3]], [[-0.6, 1.5, 1.8], [-1.0, 1.1, -2.0]]] },
  { T: [16.88, 18.0, 19.21], k: [[[-3.0, 2.5, 3.5], [-2.2, 1.0, -1.1]], [[0.0, 2.6, 3.4], [0, 1.1, -1.1]], [[3.0, 2.5, 3.5], [2.2, 1.0, -1.1]]] },
  { T: [19.21, 22.0, 25.65], k: [[[-2.0, 1.9, 3.0], [-1.0, 1.3, -2.2]], [[0.9, 1.9, 2.4], [1.8, 1.7, -3.2]], [[1.8, 2.0, 0.8], [2.3, 1.9, -3.4]]] },
  { T: [25.65, 27.2, 31.0], k: [[[-3.2, 1.9, 3.4], [-1.8, 1.7, -2.8]], [[0.2, 2.1, 3.0], [0.4, 2.4, -4.0]], [[1.6, 1.9, 2.2], [0.6, 1.5, -2.8]]] },
  { T: [31.0, 32.5, 35.45], k: [[[-3.6, 1.5, 4.0], [0.4, 1.0, -2.8]], [[-1.2, 2.0, 3.2], [1.0, 1.1, -2.6]], [[1.2, 3.0, 2.8], [1.8, 1.2, -2.3]]] },
  { T: [35.45, 36.8, DURATION], k: [[[5.4, 2.0, 1.8], [2.8, 1.4, -2.6]], [[4.8, 1.9, 0.6], [2.5, 1.4, -2.4]], [[3.9, 1.8, -0.5], [2.4, 1.4, -2.4]]] },
];

const plan = RAW.map((s, i) => {
  const ox = o(i), v = (a) => new THREE.Vector3(a[0] + ox, a[1], a[2]);
  return { T: s.T, pos: new THREE.CatmullRomCurve3(s.k.map((k) => v(k[0])), false, 'centripetal'), look: new THREE.CatmullRomCurve3(s.k.map((k) => v(k[1])), false, 'centripetal') };
});

export function shotAt(t) { let i = 0; while (i < CUTS.length - 2 && t >= CUTS[i + 1]) i++; return i; }

export function camAt(t) {
  const i = shotAt(t), p = plan[i], u = Math.min(1, Math.max(0, warpU(p.T, t)));
  const c = p.pos.getPoint(u), l = p.look.getPoint(u);
  return { shot: i, world: SHOT_WORLD[i], cam: [c.x, c.y, c.z], look: [l.x, l.y, l.z], focus: c.distanceTo(l) };
}

// 0.4 s dip to cream centred on every location change; gentle fade-out at the very end
export function dipAt(t) {
  let d = 0;
  for (let i = 1; i < CUTS.length - 1; i++) d = Math.max(d, 1 - Math.abs(t - CUTS[i]) / 0.2);
  d = Math.max(d, (t - (DURATION - 0.3)) / 0.3);
  return Math.min(1, Math.max(0, d));
}
