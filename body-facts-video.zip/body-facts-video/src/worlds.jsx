import React from 'react';
import * as THREE from 'three';
import { Solid, Sign, Facade, Room, Barrel, Crate, Lamp, Cobble, G, mat, basic, INK, rng, clamp, ease, easeOutBack } from './kit.jsx';
import { Person, PALS } from './char3.jsx';

// ---------- per-location look (fog, sky, light) ----------
export const WORLDS = [
  { name: 'hall', ox: 0, fog: ['#c9a27a', 14, 44], sky: ['#6b4a3a', '#c9a27a', '#e3c79a'], key: '#ffd9a8', ki: 2.1, hemi: ['#ffe8c8', '#6a5048', 1.0] },
  { name: 'eye', ox: 40, fog: ['#a9cfc0', 14, 40], sky: ['#7fb3a8', '#a9cfc0', '#d6e8d0'], key: '#fff0d0', ki: 2.0, hemi: ['#f1fff0', '#5b6e68', 1.05] },
  { name: 'lab', ox: 80, fog: ['#b7d0b0', 14, 40], sky: ['#6f9a86', '#b7d0b0', '#e2ecc8'], key: '#fff2d2', ki: 2.0, hemi: ['#f4ffe9', '#5f6e5a', 1.05] },
  { name: 'bench', ox: 120, fog: ['#2f3454', 12, 40], sky: ['#161a33', '#2f3454', '#6a5a78'], key: '#a9b8ff', ki: 1.0, hemi: ['#8f9ccf', '#2c2433', 0.85], stars: true },
  { name: 'micro', ox: 160, fog: ['#bcd5d9', 14, 40], sky: ['#7fa9b4', '#bcd5d9', '#e6efe0'], key: '#fff1d6', ki: 2.0, hemi: ['#f0ffff', '#5b6a70', 1.05] },
  { name: 'gym', ox: 200, fog: ['#a8715a', 14, 40], sky: ['#5a3a34', '#a8715a', '#d9a97d'], key: '#ffd2a0', ki: 2.1, hemi: ['#ffe2c0', '#5a423c', 1.0] },
  { name: 'shop', ox: 240, fog: ['#9a7a62', 14, 40], sky: ['#4f3a34', '#9a7a62', '#d2b08a'], key: '#ffd8a6', ki: 2.1, hemi: ['#ffe6c4', '#58443c', 1.0] },
  { name: 'car', ox: 280, fog: ['#2f3454', 12, 40], sky: ['#161a33', '#2f3454', '#6a5a78'], key: '#a9b8ff', ki: 1.0, hemi: ['#8f9ccf', '#2c2433', 0.85], stars: true },
];

const skyC = {};
export function skyTex(w) {
  if (skyC[w.name]) return skyC[w.name];
  const c = document.createElement('canvas'); c.width = 512; c.height = 256;
  const g = c.getContext('2d');
  const gr = g.createLinearGradient(0, 0, 0, 256);
  gr.addColorStop(0, w.sky[0]); gr.addColorStop(0.55, w.sky[1]); gr.addColorStop(1, w.sky[2]);
  g.fillStyle = gr; g.fillRect(0, 0, 512, 256);
  if (w.stars) { const r = rng(9); g.fillStyle = 'rgba(255,244,214,.9)'; for (let i = 0; i < 90; i++) g.fillRect(r() * 512, r() * 120, 2, 2); g.fillStyle = '#f3e6c8'; g.beginPath(); g.arc(380, 60, 16, 0, 6.28); g.fill(); }
  const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace;
  return (skyC[w.name] = tx);
}

const sway = (t, p = 0) => Math.sin(t * 2.9 + p);

// =====================================================================
// 1 + 9: lecture hall
// =====================================================================
export function Hall({ t, cam, s9 }) {
  const wood = mat('#9a6a45', { seed: 1, plank: 8, rep: [6, 5], wear: 2 });
  const wallM = mat('#d9b98a', { seed: 2, wear: 2 });
  const dark = mat('#5e3b2b', { seed: 3, wear: 1.5 });
  const lx = s9 ? 1.3 : 0.3;
  const pull = ease((t - 36.55) / 0.55);
  const lev = -0.85 + 1.7 * pull;
  const lit = pull > 0.99;
  const brain = lit ? mat('#f7b6bc', { seed: 7, glow: '#ff8a96', gi: 0.8 }) : mat('#e8a0a8', { seed: 7 });
  const pulse = 1 + (lit ? 0.07 * Math.sin((t - 37.1) * 9) : 0);
  const chars = s9 ? [0.12, 1.3 + 0.08 * Math.sin(t * 5)] : [0.12 + sway(t) * 0.05, 0.85 + 0.12 * Math.sin(t * 3)];
  return (
    <group>
      <Room ox={0} zc={-1} w={18} d={16} h={7} floor={wood} wall={wallM} ceil={dark} back={false} />
      <Facade w={18} h={7} d={0.6} pos={[0, 0, -9]} wall="#d9b98a" trim="#ead9b5" seed={2} lit="#fff0c0"
        wins={[{ x: -7.2, y: 2, w: 1.8, h: 3.8 }, { x: -4.3, y: 2, w: 1.8, h: 3.8 }, { x: 4.3, y: 2, w: 1.8, h: 3.8 }, { x: 7.2, y: 2, w: 1.8, h: 3.8 }]} />
      <Sign pos={[0, 2.4, -8.62]} size={[5.0, 2.1]} lines={['THE HUMAN BODY', ['a lecture in strange facts', 34]]} bg="#2f4a3f" fg="#efe8d4" w={640} />
      {[-1, 1].map((sd) => <Solid key={sd} geo={G.cyl(0.055, 0.055, 3.7, 12)} m={mat('#3a2a26')} pos={[sd * 1.95, 1.85, -4.8]} ink={0.02} />)}
      <Sign pos={[0, 3.0, -4.8]} size={[3.7, 1.15]} lines={['STRANGE FACTS OF', 'THE HUMAN BODY']} bg="#d6a436" w={640} />
      <group position={[-1.7, 0, -2.7]}>
        <Solid geo={G.box(1.2, 1.1, 0.7)} m={dark} pos={[0, 0.55, 0]} edges ink={0.03} />
        <Solid geo={G.box(1.3, 0.08, 0.85)} m={mat('#7d5238', { seed: 4 })} pos={[0, 1.15, 0.02]} rot={[-0.22, 0, 0]} ink={0.025} />
        <Sign pos={[0, 0.62, 0.38]} size={[0.7, 0.2]} lines={['PROF. HUMAN']} bg="#d6a436" w={420} />
      </group>
      {[-1, 1].map((sd) => (
        <group key={sd}>
          <Solid geo={G.box(1.6, 0.5, 10)} m={dark} pos={[sd * 7.6, 0.25, -1]} edges ink={0.03} />
          <Solid geo={G.box(1.0, 1.0, 10)} m={dark} pos={[sd * 8.5, 0.5, -1]} edges ink={0.03} />
        </group>
      ))}
      <group position={[0, 5.3, -3]}>
        <Solid geo={G.tor(1.3, 0.07)} m={mat('#3a3a40')} rot={[Math.PI / 2, 0, 0]} ink={0.025} />
        {[0, 1, 2, 3, 4, 5].map((i) => <group key={i} position={[1.3 * Math.cos(i * 1.047), 0.2, 1.3 * Math.sin(i * 1.047)]}><Solid geo={G.cyl(0.05, 0.05, 0.3, 10)} m={mat('#efe3c0')} ink={0.012} /><Solid geo={G.sph(0.07, 10, 8)} m={mat('#ffd98a', { glow: '#ffcf6a' })} pos={[0, 0.22, 0]} ink={0.01} /></group>)}
        <Solid geo={G.cyl(0.03, 0.03, 1.4, 8)} m={mat('#3a3a40')} pos={[0, 0.8, 0]} ink={0.015} />
        <pointLight position={[0, -0.2, 0]} intensity={14} distance={14} color="#ffd9a0" />
      </group>
      <group position={[3.4, 0, -2.7]}>
        <Solid geo={G.cyl(0.38, 0.5, 0.9)} m={dark} pos={[0, 0.45, 0]} ink={0.03} />
        <Solid geo={G.cyl(0.85, 0.85, 0.1)} m={mat('#7d5238', { seed: 5 })} pos={[0, 0.95, 0]} ink={0.03} />
        <group position={[0, 1.38, 0]} scale={pulse}>
          <Solid geo={G.ico(0.42, 1)} m={brain} scale={[1.25, 0.9, 1]} ink={0.025} edges />
          {[-0.28, 0, 0.28].map((x, i) => <Solid key={i} geo={G.ico(0.17, 1)} m={brain} pos={[x, 0.3 - Math.abs(x) * 0.35, 0.12 * (i - 1)]} ink={0.02} />)}
        </group>
      </group>
      {s9 && <group position={[2.0, 0, -2.4]}>
        <Solid geo={G.box(0.6, 0.3, 0.5)} m={mat('#3a3a40')} pos={[0, 0.15, 0]} ink={0.025} />
        <Solid geo={G.cyl(0.05, 0.05, 0.9, 10)} m={mat('#c9c0b0')} pos={[0, 0.7, 0]} ink={0.02} />
        <group position={[0, 0.95, 0.06]} rotation={[0, 0, -lev]}>
          <Solid geo={G.cyl(0.04, 0.04, 0.95, 10)} m={mat('#b8b0a0')} pos={[0, 0.45, 0]} ink={0.02} />
          <Solid geo={G.sph(0.1, 14, 10)} m={mat('#b83f3a', { seed: 6 })} pos={[0, 0.95, 0]} ink={0.02} />
        </group>
        <Sign pos={[0.1, 1.95, 0]} size={[1.3, 0.34]} lines={['OVERRIDE']} bg="#b83f3a" fg="#f6ead0" w={420} />
        <Solid geo={G.cyl(0.03, 0.03, 0.8, 8)} m={mat('#3a3a40')} pos={[0.1, 1.5, -0.04]} ink={0.015} />
      </group>}
      <group position={[1.75, 0, 0.8]}>
        <Solid geo={G.cyl(0.38, 0.34, 0.7)} m={dark} pos={[0, 0.35, 0]} ink={0.03} />
        <Solid geo={G.box(0.6, 0.12, 0.45)} m={mat('#b83f3a', { seed: 8 })} pos={[0.02, 0.76, 0]} rot={[0, 0.3, 0]} ink={0.025} />
      </group>
      <Person pos={[lx, 0, -2.4]} cam={cam} s={1.05} t={t} pal={PALS.prof} arms={chars} />
    </group>
  );
}

// =====================================================================
// 2: eye-test room with a giant blurred nose near the lens
// =====================================================================
export function EyeRoom({ t, cam }) {
  const ox = 40;
  return (
    <group>
      <Room ox={ox} zc={-1} w={16} d={16} h={7} floor={mat('#b9a98c', { seed: 31, tile: 6, rep: [6, 6], wear: 2 })} wall={mat('#a9d0c0', { seed: 32, wear: 2 })} ceil={mat('#8fb5a6')} />
      <Sign pos={[ox + 2.3, 2.5, -8.78]} size={[2.1, 3.0]} lines={[['E', 150], ['F  P', 100], ['T O Z', 70], ['L P E D', 48], ['P E C F D', 34]]} bg="#f1ead8" w={420} h={600} />
      <Sign pos={[ox - 2.4, 4.6, -8.78]} size={[2.6, 0.5]} lines={['EYE EXAM ROOM']} bg="#d6a436" w={520} />
      <group position={[ox - 2.0, 0, -5.4]}>
        <Solid geo={G.box(1.1, 0.14, 1.0)} m={mat('#7d5238', { seed: 33 })} pos={[0, 0.55, 0]} ink={0.025} />
        <Solid geo={G.box(1.1, 1.1, 0.14)} m={mat('#7d5238', { seed: 34 })} pos={[0, 1.1, -0.45]} ink={0.025} />
        {[-0.45, 0.45].map((x) => <Solid key={x} geo={G.box(0.1, 0.55, 0.1)} m={mat('#5e3b2b')} pos={[x, 0.27, 0.4]} ink={0.02} />)}
      </group>
      <Solid geo={G.box(0.5, 0.06, 0.5)} m={mat('#3a3a40')} pos={[ox + 1.0, 0.03, -3.4]} ink={0.02} />
      <Solid geo={G.cyl(0.04, 0.04, 2.4)} m={mat('#c9c0b0')} pos={[ox + 1.0, 1.2, -3.4]} ink={0.02} />
      {/* giant nose model near the lens */}
      <group position={[ox - 0.9, 0, 2.5]} rotation={[0, 0.25, 0]}>
        <Solid geo={G.cyl(0.14, 0.2, 1.0)} m={mat('#5e3b2b', { seed: 35 })} pos={[0, 0.5, 0]} ink={0.03} />
        <group position={[0, 1.55, 0]}>
          <Solid geo={G.sph(0.4, 22, 16)} m={mat('#efbf9a', { seed: 36 })} scale={[0.7, 1.15, 0.8]} pos={[0, 0.1, -0.05]} ink={0.035} />
          <Solid geo={G.sph(0.34, 22, 16)} m={mat('#efbf9a', { seed: 37 })} scale={[1.15, 0.9, 1]} pos={[0, -0.36, 0.12]} ink={0.035} />
          {[-1, 1].map((sd) => <Solid key={sd} geo={G.sph(0.09, 12, 10)} m={mat('#6a3b34', { seed: 38 })} scale={[0.8, 1.2, 0.7]} pos={[sd * 0.16, -0.5, 0.42]} ink={0.012} />)}
        </group>
      </group>
      <Person pos={[ox + 0.1, 0, -4.4]} cam={cam} s={1.1} t={t} pal={PALS.bowler} arms={[0.12, 0.12 + 0.05 * Math.sin(t * 3)]} />
    </group>
  );
}

// =====================================================================
// 3: torso model with drifting organs
// =====================================================================
export function TorsoLab({ t, cam }) {
  const ox = 80;
  const d = (a, b, p) => [0.05 * Math.sin(t * 1.7 + p) * a, 0.045 * Math.sin(t * 1.3 + p * 2) * b, 0];
  const skin = mat('#e8c9a8', { seed: 41 });
  const org = (x, y, p, a = 1) => { const o = d(a, a, p); return [x + o[0], y + o[1], -2.72]; };
  return (
    <group>
      <Room ox={ox} zc={-1} w={16} d={14} h={7} floor={mat('#8aa08a', { seed: 42, tile: 6, rep: [6, 6], wear: 2 })} wall={mat('#b7d6bd', { seed: 43, tile: 4, wear: 2 })} ceil={mat('#8ab097')} />
      <group position={[ox, 0, 0]}>
        <Solid geo={G.box(3.4, 0.16, 1.6)} m={mat('#9a6a45', { seed: 44, plank: 6 })} pos={[0, 0.95, -2.6]} edges ink={0.03} />
        {[-1.5, 1.5].flatMap((x) => [-3.2, -2.0].map((z) => <Solid key={x + '' + z} geo={G.box(0.15, 0.95, 0.15)} m={mat('#5e3b2b')} pos={[x, 0.47, z]} ink={0.02} />))}
        <Sign pos={[0, 0.86, -1.78]} size={[1.5, 0.3]} lines={['ORGANS (SHIFTING)']} bg="#d6a436" w={560} />
        {/* torso tray */}
        <Solid geo={G.box(1.6, 1.6, 0.1)} m={skin} pos={[0, 1.83, -2.95]} ink={0.03} edges />
        {[-0.75, 0.75].map((x) => <Solid key={x} geo={G.box(0.1, 1.6, 0.5)} m={skin} pos={[x, 1.83, -2.72]} ink={0.03} />)}
        <Solid geo={G.box(1.6, 0.1, 0.5)} m={skin} pos={[0, 1.08, -2.72]} ink={0.03} />
        <Solid geo={G.box(1.6, 0.1, 0.5)} m={skin} pos={[0, 2.63, -2.72]} ink={0.03} />
        {[-1, 1].map((sd, i) => <Solid key={i} geo={G.sph(0.3, 18, 12)} m={mat('#e79aa6', { seed: 45 + i })} scale={[0.95, 1.3, 0.7]} pos={org(sd * 0.36, 2.2, i * 2.1)} ink={0.03} />)}
        <Solid geo={G.ico(0.2, 1)} m={mat('#c93f4a', { seed: 47 })} pos={org(0.05, 2.0, 3.3)} ink={0.025} />
        <Solid geo={G.sph(0.26, 18, 12)} m={mat('#e8a35d', { seed: 48 })} scale={[1.3, 0.8, 0.7]} pos={org(-0.18, 1.62, 4.4)} ink={0.03} />
        <Solid geo={G.knot(0.2, 0.075)} m={mat('#e7b28f', { seed: 49 })} pos={org(0.05, 1.3, 5.2, 0.8)} ink={0.025} />
        <group position={[0, 5.2, -2.6]}>
          <Solid geo={G.cyl(0.03, 0.03, 2.4, 8)} m={mat('#3a3a40')} pos={[0, 1.2, 0]} ink={0.015} />
          <Solid geo={G.sph(0.9, 24, 12)} m={mat('#c9d4d0', { seed: 50 })} scale={[1, 0.42, 1]} ink={0.03} />
          <pointLight position={[0, -0.5, 0.8]} intensity={16} distance={12} color="#fff4de" />
        </group>
        <group position={[-2.5, 0, 1.2]}>
          <Solid geo={G.cyl(0.03, 0.03, 3.6, 8)} m={mat('#c9c0b0')} pos={[0, 1.8, 0]} ink={0.02} />
          <Solid geo={G.cyl(0.4, 0.4, 0.06)} m={mat('#3a3a40')} pos={[0, 0.03, 0]} ink={0.02} />
          <Solid geo={G.cyl(0.12, 0.12, 0.5, 12)} m={mat('#a9d8e0', { opacity: 0.8 })} pos={[0.2, 3.0, 0]} ink={0.015} />
        </group>
      </group>
      <Person pos={[ox + 2.4, 0, -2.0]} cam={cam} s={1.05} t={t} phase={1.4} pal={PALS.cap} />
    </group>
  );
}

// =====================================================================
// street kit (bench + car worlds)
// =====================================================================
function Street({ ox, t }) {
  const cols = ['#b5573f', '#7e8f97', '#c79a62', '#6a7f69', '#a95a5f'];
  const wins = (r) => [{ x: -2.4, y: 1.5, w: 1.2, h: 1.7 }, { x: 2.4, y: 1.5, w: 1.2, h: 1.7 }, { x: -2.4, y: 3.9, w: 1.2, h: 1.7 }, { x: 0, y: 3.9, w: 1.2, h: 1.7 }, { x: 2.4, y: 3.9, w: 1.2, h: 1.7 }].filter((_, i) => (i + r) % 4 !== 3);
  return (
    <group>
      <Cobble ox={ox} />
      {[-16, -8, 0, 8, 16].map((x, i) => (
        <Facade key={i} w={8} h={6.5 + (i % 2)} d={0.6} pos={[ox + x, 0, -7.6]} wall={cols[i]} seed={i + 3} brickRows={i % 2 ? 0 : 8}
          wins={wins(i)} door={i % 2 ? null : { x: 0, w: 1.4, h: 2.5 }} lit={i === 2 ? '#3a3a52' : '#ffd98a'} />
      ))}
      <Facade w={12} h={9} d={0.6} pos={[ox - 6, 0, -14]} wall="#4d4a66" seed={20} wins={[{ x: -2, y: 2, w: 1.2, h: 1.6 }, { x: 2, y: 4, w: 1.2, h: 1.6 }]} lit="#ffcf7a" />
      <Facade w={12} h={8} d={0.6} pos={[ox + 8, 0, -14]} wall="#5a4a5c" seed={21} wins={[{ x: -2, y: 3, w: 1.2, h: 1.6 }, { x: 2, y: 5.4, w: 1.2, h: 1.6 }]} lit="#ffcf7a" />
    </group>
  );
}

// =====================================================================
// 4: the lonely bench
// =====================================================================
export function BenchStreet({ t, cam }) {
  const ox = 120;
  return (
    <group>
      <Street ox={ox} t={t} />
      <Lamp pos={[ox + 2.7, 0, -3.0]} t={t} />
      <group position={[ox - 0.2, 0, -3.1]}>
        <Solid geo={G.box(3.8, 0.12, 0.7)} m={mat('#8a5a3c', { seed: 51, plank: 4 })} pos={[0, 0.52, 0]} edges ink={0.03} />
        <Solid geo={G.box(3.8, 0.7, 0.1)} m={mat('#8a5a3c', { seed: 52, plank: 4 })} pos={[0, 1.0, -0.32]} edges ink={0.03} />
        {[-1.7, 1.7].map((x) => <Solid key={x} geo={G.box(0.12, 0.5, 0.7)} m={mat('#2f3a3a')} pos={[x, 0.25, 0]} ink={0.025} />)}
      </group>
      <group position={[ox + 4.7, 0, -3.1]}>
        <Solid geo={G.cyl(0.05, 0.05, 2.6, 8)} m={mat('#2f3a3a')} pos={[0, 1.3, 0]} ink={0.02} />
        <Sign pos={[0, 2.55, 0.1]} size={[1.0, 0.55]} lines={['BUS', 'STOP']} bg="#2c6a8a" fg="#f4ead2" w={360} />
      </group>
      <Barrel pos={[ox - 3.4, 0, 1.0]} />
      <Person pos={[ox - 1.3, 0, -1.9]} cam={cam} s={1.05} t={t} phase={2.2} pal={PALS.bare} arms={[0.08, 0.08]} />
    </group>
  );
}

// =====================================================================
// 5: petri dishes with built-in company
// =====================================================================
export function Lab({ t, cam }) {
  const ox = 160;
  const popAt = [17.3, 17.85, 18.5];
  const dishX = [-2.3, 0, 2.3];
  const r = rng(77);
  const colonies = React.useMemo(() => ({
    fungus: Array.from({ length: 10 }, () => [(r() - .5) * 1.0, (r() - .5) * 1.0, 0.07 + r() * 0.1]),
    bact: Array.from({ length: 16 }, () => [(r() - .5) * 1.2, (r() - .5) * 1.2, r() * 3.1]),
    mites: Array.from({ length: 6 }, () => [(r() - .5) * 1.0, (r() - .5) * 1.0, r() * 3.1]),
  }), []);
  const dish = (x, i, content) => (
    <group key={i} position={[ox + x, 0.99, -0.95]}>
      <Solid geo={G.cyl(0.88, 0.88, 0.16, 40)} m={mat('#bfe3e6', { opacity: 0.55 })} pos={[0, 0.08, 0]} ink={0.025} />
      <Solid geo={G.cyl(0.8, 0.8, 0.08, 40)} m={mat('#f2dfa6', { seed: 60 + i, wear: 1 })} pos={[0, 0.06, 0]} ink={0.01} />
      {content}
      <group scale={easeOutBack((t - popAt[i]) / 0.3)}>
        <Sign pos={[0, 0.1, 1.25]} rot={[-1.15, 0, 0]} size={[1.2, 0.4]} lines={[['MITES', 'FUNGUS', 'BACTERIA'][i]]} bg="#f1ead8" w={420} />
      </group>
    </group>
  );
  return (
    <group>
      <Room ox={ox} zc={-1} w={16} d={14} h={7} floor={mat('#8a7a68', { seed: 61, plank: 8, rep: [5, 5], wear: 2 })} wall={mat('#b9d3d8', { seed: 62, tile: 4, wear: 2 })} ceil={mat('#97b5bb')} />
      <group position={[ox, 0, 0]}>
        <Solid geo={G.box(8.2, 0.14, 2.3)} m={mat('#9a6a45', { seed: 63, plank: 6 })} pos={[0, 0.9, -0.9]} edges ink={0.03} />
        {[-3.9, 3.9].flatMap((x) => [-1.9, 0.1].map((z) => <Solid key={x + '' + z} geo={G.box(0.2, 0.9, 0.2)} m={mat('#5e3b2b')} pos={[x, 0.45, z]} ink={0.02} />))}
      </group>
      {dish(dishX[0], 0, colonies.mites.map((c, i) => (
        <group key={i} position={[c[0], 0.17, c[1]]} rotation={[0, c[2] + t * 0.7 + i, 0]}>
          <Solid geo={G.sph(0.11, 14, 10)} m={mat('#8b5a3c', { seed: 64 })} scale={[1.2, 0.85, 1]} pos={[0, 0.07, 0]} ink={0.015} />
          {[0, 1.05, 2.1].map((a, k) => <Solid key={k} geo={G.box(0.3, 0.025, 0.025)} m={mat('#5a3a2a')} pos={[0, 0.05, 0]} rot={[0, a, 0]} ink={0.008} />)}
        </group>
      )))}
      {dish(dishX[1], 1, colonies.fungus.map((c, i) => <Solid key={i} geo={G.ico(c[2], 1)} m={mat(i % 2 ? '#8fa57a' : '#b9c79a', { seed: 65 + i })} pos={[c[0], 0.15 + c[2] * 0.5, c[1]]} ink={0.015} />))}
      {dish(dishX[2], 2, colonies.bact.map((c, i) => <Solid key={i} geo={G.cap(0.045, 0.16)} m={mat('#4fa7a0', { seed: 70 + (i % 3) })} pos={[c[0], 0.14, c[1]]} rot={[0, c[2] + 0.2 * Math.sin(t * 2 + i), Math.PI / 2]} ink={0.01} />))}
      <group position={[ox - 1.1, 0, 1.1]}>
        <Solid geo={G.cyl(0.32, 0.3, 0.55)} m={mat('#8a5a3c', { seed: 66 })} pos={[0, 0.27, 0]} ink={0.03} />
        <Solid geo={G.cone(0.34, 0.6)} m={mat('#a9d8e0', { opacity: 0.8 })} pos={[0, 0.86, 0]} ink={0.02} />
        <Solid geo={G.cyl(0.09, 0.09, 0.3, 12)} m={mat('#a9d8e0', { opacity: 0.8 })} pos={[0, 1.3, 0]} ink={0.015} />
      </group>
      <Person pos={[ox, 0, -2.7]} cam={cam} s={1.12} t={t} phase={0.7} pal={{ ...PALS.prof, jacket: '#8a4f6d', tie: '#d6a436' }} />
    </group>
  );
}

// =====================================================================
// 6: strongman gym with the force-o-meter
// =====================================================================
const ang = (v) => v * 4.2 - 2.1;
let dialT;
function dialTex() {
  if (dialT) return dialT;
  const S = 512, c = document.createElement('canvas'); c.width = c.height = S;
  const g = c.getContext('2d'), cx = S / 2, cy = S / 2;
  g.fillStyle = '#efe2c0'; g.beginPath(); g.arc(cx, cy, 250, 0, 6.28); g.fill();
  g.lineWidth = 34;
  const arc = (a, b, col) => { g.strokeStyle = col; g.beginPath(); g.arc(cx, cy, 190, -Math.PI / 2 + ang(a), -Math.PI / 2 + ang(b)); g.stroke(); };
  arc(0, 0.6, '#5d9a5e'); arc(0.6, 1, '#b83f3a');
  g.strokeStyle = INK; g.lineWidth = 6;
  for (let i = 0; i <= 10; i++) { const a = -Math.PI / 2 + ang(i / 10); g.beginPath(); g.moveTo(cx + 215 * Math.cos(a), cy + 215 * Math.sin(a)); g.lineTo(cx + 238 * Math.cos(a), cy + 238 * Math.sin(a)); g.stroke(); }
  g.fillStyle = INK; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = 'bold 44px Georgia, "DejaVu Serif", serif';
  [[0, '0'], [0.6, '60%'], [1, '100%']].forEach(([v, s]) => { const a = -Math.PI / 2 + ang(v); g.fillText(s, cx + 148 * Math.cos(a), cy + 148 * Math.sin(a)); });
  g.font = 'bold 36px Georgia, "DejaVu Serif", serif'; g.fillText('FORCE-O-METER', cx, cy + 172);
  g.strokeStyle = INK; g.lineWidth = 10; g.beginPath(); g.arc(cx, cy, 250, 0, 6.28); g.stroke();
  dialT = new THREE.CanvasTexture(c); dialT.colorSpace = THREE.SRGBColorSpace;
  return dialT;
}
export function Gym({ t, cam }) {
  const ox = 200;
  const x = clamp((t - 20.94) / 1.35);
  const e = 1 - Math.pow(1 - x, 3);
  let v = 0.6 * e;
  if (t > 22.3) v = 0.6 + 0.014 * Math.sin((t - 22.3) * 20) * Math.exp(-(t - 22.3) * 1.4) + 0.004 * Math.sin(t * 31);
  const th = 2.1 - 4.2 * v;
  const locked = t > 24.1;
  const a60 = ang(0.6);
  const plate = (xx) => <Solid key={xx} geo={G.cyl(0.42, 0.42, 0.1, 28)} m={mat('#3b3b46', { seed: 81 })} pos={[xx, 0, 0]} rot={[0, 0, Math.PI / 2]} ink={0.025} />;
  return (
    <group>
      <Room ox={ox} zc={-1} w={18} d={14} h={7} floor={mat('#6b4a36', { seed: 82, plank: 8, rep: [6, 5], wear: 2.5 })} wall={mat('#a8563f', { seed: 83, brick: 8, wear: 2, rep: [4, 2] })} ceil={mat('#4a3430')} />
      <group position={[ox - 1.0, 1.02, -2.05]}>
        <Solid geo={G.cyl(0.04, 0.04, 2.7, 12)} m={mat('#c9c0b0')} rot={[0, 0, Math.PI / 2]} ink={0.02} />
        {[1.0, 1.15, 1.3].map((o) => [o, -o]).flat().map((xx) => plate(xx))}
        {[1.62, -1.62].map((xx) => <Solid key={xx} geo={G.cyl(0.07, 0.07, 0.25, 12)} m={mat('#c9c0b0')} pos={[xx, 0, 0]} rot={[0, 0, Math.PI / 2]} ink={0.015} />)}
      </group>
      <group position={[ox + 2.7, 0, -3.5]}>
        <Solid geo={G.box(0.4, 1.3, 0.3)} m={mat('#4a3a30', { seed: 84 })} pos={[0, 0.65, 0]} ink={0.03} />
        <Solid geo={G.cyl(1.4, 1.4, 0.2, 40)} m={mat('#c79a42', { seed: 85 })} pos={[0, 2.25, 0]} rot={[Math.PI / 2, 0, 0]} ink={0.04} />
        <mesh position={[0, 2.25, 0.115]}><circleGeometry args={[1.3, 48]} /><meshBasicMaterial map={dialTex()} fog={false} /></mesh>
        <mesh position={[Math.sin(a60) * 1.18, 2.25 + Math.cos(a60) * 1.18, 0.13]}><boxGeometry args={[0.16, 0.16, 0.06]} /><meshBasicMaterial color={locked ? '#ff4d3d' : '#7a2a25'} fog={false} /></mesh>
        <group position={[0, 2.25, 0.16]} rotation={[0, 0, th]}>
          <Solid geo={G.box(0.07, 1.05, 0.04)} m={mat('#b83f3a', { seed: 86 })} pos={[0, 0.42, 0]} ink={0.015} />
          <Solid geo={G.cyl(0.1, 0.1, 0.06, 18)} m={mat('#2a1f24')} rot={[Math.PI / 2, 0, 0]} ink={0.012} />
        </group>
      </group>
      <group position={[ox + 0.6, 0, 1.4]}>
        <Solid geo={G.sph(0.34, 20, 14)} m={mat('#3b3b46', { seed: 87 })} pos={[0, 0.34, 0]} ink={0.03} />
        <Solid geo={G.tor(0.2, 0.05, Math.PI)} m={mat('#3b3b46', { seed: 87 })} pos={[0, 0.62, 0]} ink={0.02} />
      </group>
      <Person pos={[ox - 1.0, 0, -2.3]} cam={cam} s={1.1} t={t} pal={PALS.cap} arms={[1.36, 1.36]} />
    </group>
  );
}

// =====================================================================
// 7: workshop rig that tears at 100%
// =====================================================================
export function Workshop({ t, cam }) {
  const ox = 240;
  const tear = ease((t - 29.05) / 0.85);
  const snap = ease((t - 30.55) / 0.3);
  const bone = mat('#efe6d0', { seed: 93 });
  return (
    <group>
      <Room ox={ox} zc={-1} w={18} d={14} h={7} floor={mat('#6b4a36', { seed: 91, plank: 8, rep: [6, 5], wear: 2.5 })} wall={mat('#a8563f', { seed: 92, brick: 8, wear: 2, rep: [4, 2] })} ceil={mat('#4a3430')} />
      <Sign pos={[ox, 3.4, -7.8]} size={[4.2, 1.5]} lines={[['100%', 120], ['POWER', 60]]} bg="#e6b92e" stripes w={640} />
      {[-1, 1].map((sd) => <Solid key={sd} geo={G.box(0.6, 3.4, 0.6)} m={mat('#7d5238', { seed: 94, plank: 3 })} pos={[ox + sd * 2.75, 1.7, -3.2]} edges ink={0.03} />)}
      {[0, 1, 2, 3, 4, 5].map((i) => {
        const a = (i / 6) * Math.PI * 2, oy = Math.sin(a) * 0.14, oz = Math.cos(a) * 0.14;
        const fr = tear * (0.5 + 0.5 * ((i * 37) % 6) / 5);
        const col = mat(i % 2 ? '#d98a6a' : '#c25648', { seed: 95 + i });
        return (
          <group key={i} position={[ox, 1.95 + oy, -3.2 + oz]}>
            {[-1, 1].map((sd) => (
              <group key={sd} position={[sd * 2.45, 0, 0]} rotation={[0.25 * fr * (i % 2 ? 1 : -1), 0, -sd * fr * (0.9 + 0.15 * (i % 3)) * 1.0]}>
                <Solid geo={G.cyl(0.055, 0.055, 2.45, 10)} m={col} pos={[-sd * 1.22, 0, 0]} rot={[0, 0, Math.PI / 2]} ink={0.015} />
              </group>
            ))}
          </group>
        );
      })}
      {[-1, 1].map((sd) => <Solid key={sd} geo={G.sph(0.5, 22, 14)} m={mat('#b8453d', { seed: 99 })} scale={[1.0, 0.62, 0.62]} pos={[ox + sd * (0.46 + 0.7 * tear), 1.95 - 0.5 * tear, -3.2]} rot={[0, 0, -sd * 0.6 * tear]} ink={0.03} />)}
      <group position={[ox, 0, -1.7]}>
        <Solid geo={G.box(4.6, 0.8, 0.9)} m={mat('#7d5238', { seed: 96, plank: 4 })} pos={[0, 0.4, 0]} edges ink={0.03} />
        {[-1, 1].map((sd) => (
          <group key={sd} position={[sd * 1.5, 0, 0]} rotation={[0, 0, -sd * 0.38 * snap]}>
            <Solid geo={G.cyl(0.12, 0.12, 1.5, 14)} m={bone} pos={[-sd * 0.75, 1.0, 0]} rot={[0, 0, Math.PI / 2]} ink={0.02} />
            {[-1, 1].map((k) => <Solid key={k} geo={G.sph(0.19, 14, 10)} m={bone} pos={[-sd * (k > 0 ? 1.5 : 0.0), 1.0 + 0.1 * k * 0, 0.1 * k]} ink={0.02} />)}
          </group>
        ))}
      </group>
      <Crate pos={[ox - 1.4, 0, 1.4]} s={1.1} rot={[0, 0.4, 0]} />
      <Person pos={[ox - 4.6, 0, -1.0]} cam={cam} s={1.05} t={t} phase={3.1} pal={PALS.bowler} arms={[0.1 + 0.35 * snap + 0.2 * tear, 0.1 + 0.35 * snap]} />
    </group>
  );
}

// =====================================================================
// 8: night street, lifting a car
// =====================================================================
export function CarStreet({ t, cam }) {
  const ox = 280;
  const lift = ease((t - 31.85) / 0.95);
  const phi = 0.2 * lift, psi = 0.1 * lift;
  const body = mat('#c4473a', { seed: 101, wear: 1.5 });
  const glass = mat('#a8d0d8', { seed: 102, glow: '#6aa0b0', gi: 0.5 });
  const dk = mat('#2d2a33', { seed: 103 });
  return (
    <group>
      <Street ox={ox} t={t} />
      <Lamp pos={[ox - 4.2, 0, -3.1]} t={t} />
      <Lamp pos={[ox + 5.6, 0, -3.1]} t={t} />
      <group position={[ox - 1.6, 0, -3.7]} rotation={[-phi, 0, psi]}>
        <group position={[1.6, 0, 0.7]}>
          <Solid geo={G.box(3.3, 0.7, 1.45)} m={body} pos={[0, 0.7, 0]} edges ink={0.035} />
          <Solid geo={G.box(1.7, 0.6, 1.3)} m={glass} pos={[-0.15, 1.3, 0]} edges ink={0.035} />
          <Solid geo={G.box(1.78, 0.08, 1.36)} m={body} pos={[-0.15, 1.64, 0]} ink={0.03} />
          {[[1.0, 0.72], [-1.0, 0.72], [1.0, -0.72], [-1.0, -0.72]].map(([x, z], i) => (
            <group key={i}>
              <Solid geo={G.cyl(0.38, 0.38, 0.24, 24)} m={dk} pos={[x, 0.38, z]} rot={[Math.PI / 2, 0, 0]} ink={0.03} />
              <Solid geo={G.cyl(0.17, 0.17, 0.26, 16)} m={mat('#c9c0b0')} pos={[x, 0.38, z]} rot={[Math.PI / 2, 0, 0]} ink={0.012} />
            </group>
          ))}
          {[-0.5, 0.5].map((z) => <Solid key={z} geo={G.box(0.08, 0.2, 0.3)} m={mat('#ffe9a0', { glow: '#ffe08a', gi: 1.2 })} pos={[1.66, 0.8, z]} ink={0.015} />)}
        </group>
      </group>
      <Barrel pos={[ox - 2.6, 0, 1.4]} />
      <Person pos={[ox + 2.4, 0, -2.0]} cam={cam} s={1.1} t={t} phase={0.4} pal={PALS.bare} arms={[0.15 + 1.75 * lift + 0.25 * Math.sin(t * 20) * lift * 0.2, 0.2]} />
    </group>
  );
}
