import React from 'react';
import * as THREE from 'three';
import { INK, basic, clamp } from './kit.jsx';

const cache = {};
const memo = (k, f) => cache[k] || (cache[k] = f());
const shapeGeo = (k, build) => memo('g' + k, () => new THREE.ShapeGeometry(build(), 28));

const circle = (r) => memo('c' + r, () => new THREE.CircleGeometry(r, 36));
const ellipse = (rx, ry) => shapeGeo(`e${rx},${ry}`, () => { const s = new THREE.Shape(); s.absellipse(0, 0, rx, ry, 0, Math.PI * 2, false); return s; });
const rect = (w, h) => memo(`r${w},${h}`, () => new THREE.PlaneGeometry(w, h));
const poly = (k, pts) => shapeGeo(k, () => { const s = new THREE.Shape(); s.moveTo(...pts[0]); pts.slice(1).forEach((p) => s.lineTo(...p)); s.closePath(); return s; });
const taper = (tw, bw, len, k) => shapeGeo(`t${tw},${bw},${len},${k}`, () => { const s = new THREE.Shape(); s.moveTo(-tw / 2, 0); s.lineTo(tw / 2, 0); s.lineTo(bw / 2, -len); s.lineTo(-bw / 2, -len); s.closePath(); return s; });

const pear = () => shapeGeo('pear', () => {
  const s = new THREE.Shape();
  s.moveTo(-0.13, 0.27); s.bezierCurveTo(-0.2, 0.27, -0.3, -0.05, -0.27, -0.2); s.bezierCurveTo(-0.25, -0.32, -0.12, -0.34, 0, -0.34);
  s.bezierCurveTo(0.12, -0.34, 0.25, -0.32, 0.27, -0.2); s.bezierCurveTo(0.3, -0.05, 0.2, 0.27, 0.13, 0.27); s.closePath(); return s;
});
const pearTop = () => shapeGeo('pearTop', () => {
  const s = new THREE.Shape();
  s.moveTo(-0.13, 0.27); s.bezierCurveTo(-0.19, 0.27, -0.27, 0.05, -0.268, -0.04); s.lineTo(0.268, -0.04); s.bezierCurveTo(0.27, 0.05, 0.19, 0.27, 0.13, 0.27); s.closePath(); return s;
});
const fringe = () => shapeGeo('fringe', () => {
  const s = new THREE.Shape();
  s.absarc(0, 0, 0.315, Math.PI * 0.08, Math.PI * 0.92, false);
  s.lineTo(-0.25, 0.1); s.quadraticCurveTo(-0.17, 0.2, -0.1, 0.1); s.quadraticCurveTo(-0.02, 0.22, 0.06, 0.1); s.quadraticCurveTo(0.14, 0.2, 0.21, 0.09); s.lineTo(0.27, 0.12); s.closePath(); return s;
});
const halfDisc = (r) => shapeGeo('hd' + r, () => { const s = new THREE.Shape(); s.absarc(0, 0, r, Math.PI, Math.PI * 2, false); s.closePath(); return s; });
const smile = () => shapeGeo('smile', () => {
  const s = new THREE.Shape(); s.absarc(0, 0, 0.1, Math.PI * 1.16, Math.PI * 1.84, false); s.absarc(0, 0, 0.083, Math.PI * 1.84, Math.PI * 1.16, true); s.closePath(); return s;
});
const dome = (r) => shapeGeo('dome' + r, () => { const s = new THREE.Shape(); s.absarc(0, 0, r, 0, Math.PI, false); s.closePath(); return s; });
const ring = (ro, ri) => shapeGeo(`ring${ro},${ri}`, () => { const s = new THREE.Shape(); s.absarc(0, 0, ro, 0, Math.PI * 2, false); const h = new THREE.Path(); h.absarc(0, 0, ri, 0, Math.PI * 2, true); s.holes.push(h); return s; });

const mm = (c) => basic(c);
const inkM = basic(INK);

// one flat piece with a slightly wobbly hand-drawn ink band behind it
function Flat({ geo, pos = [0, 0, 0], rot = 0, color, z = 0, ink = [1.1, 1.1], seed = 0 }) {
  const wob = 0.025 * Math.sin(seed * 12.9 + 1.7);
  return (
    <group position={[pos[0], pos[1], z]} rotation={[0, 0, rot]}>
      {ink && <mesh geometry={geo} material={inkM} scale={[ink[0], ink[1], 1]} position={[0.004 * Math.cos(seed * 5.1), 0.004 * Math.sin(seed * 3.3), -0.004]} rotation={[0, 0, wob]} />}
      <mesh geometry={geo} material={mm(color)} />
    </group>
  );
}

export const PALS = {
  prof: { jacket: '#3f5a73', pants: '#6a4b3c', skin: '#f6e6cf', hair: '#2e2223', tie: '#b83f3a', hat: { type: 'top', color: '#2b2a35' }, glasses: true },
  cap: { jacket: '#b8703a', pants: '#3e4c5e', skin: '#f6e6cf', hair: '#6b3d27', tie: '#2f6f6b', hat: { type: 'cap', color: '#d6a436' }, glasses: false },
  bowler: { jacket: '#5d7a4e', pants: '#4a3a45', skin: '#f3dfc6', hair: '#2e2223', tie: '#d6a436', hat: { type: 'bowler', color: '#3a3040' }, glasses: false },
  bare: { jacket: '#8a4f6d', pants: '#3a4a5a', skin: '#f8e8d2', hair: '#c9873f', tie: '#2f6f6b', hat: null, glasses: true },
};

export function Person({ pos, cam, s = 1, t = 0, phase = 0, pal = PALS.prof, arms, yawMax = 0.7, blink = true }) {
  const yaw = clamp(Math.atan2(cam[0] - pos[0], cam[2] - pos[2]), -yawMax, yawMax);
  const bob = 0.014 * Math.sin(t * 5.4 + phase);
  const nod = 0.045 * Math.sin(t * 2.3 + phase);
  const sway = 0.05 * Math.sin(t * 2.9 + phase * 1.7);
  const [aL, aR] = arms || [0.1 + sway, 0.1 - sway];
  const arm = (side, a, i) => {
    const th = side * a;
    return (
      <group position={[side * 0.2, 1.0, 0.05]} rotation={[0, 0, th]}>
        <Flat geo={taper(0.062, 0.036, 0.46, 'arm')} color={pal.jacket} ink={[1.7, 1.04]} seed={i} />
        <Flat geo={circle(0.055)} pos={[0, -0.47]} color="#2a1f24" z={0.004} ink={[1.18, 1.18]} seed={i + 4} />
      </group>
    );
  };
  const blinkK = blink && Math.sin(t * 1.3 + phase * 3) > 0.985 ? 0.2 : 1;
  const hat = pal.hat;
  return (
    <group>
      <mesh position={[pos[0], 0.014, pos[2]]} rotation={[-Math.PI / 2, 0, 0]} scale={[0.5 * s, 0.2 * s, 1]}>
        <circleGeometry args={[1, 28]} />
        <meshBasicMaterial color="#1a1014" transparent opacity={0.33} depthWrite={false} fog={false} />
      </mesh>
      <group position={[pos[0], pos[1] + bob, pos[2]]} rotation={[0, yaw, 0]} scale={s}>
        {[-1, 1].map((sd, i) => (
          <group key={i}>
            <Flat geo={taper(0.075, 0.045, 0.5, 'leg')} pos={[sd * 0.11, 0.5]} color={pal.pants} z={0.0} ink={[1.7, 1.03]} seed={i + 10} />
            <Flat geo={ellipse(0.085, 0.04)} pos={[sd * 0.125 + sd * 0.03, 0.035]} color="#2a1f24" z={0.003} ink={[1.15, 1.3]} seed={i + 20} />
          </group>
        ))}
        <Flat geo={pear()} pos={[0, 0.8]} color={pal.pants} z={0.01} ink={[1.07, 1.07]} seed={30} />
        <Flat geo={pearTop()} pos={[0, 0.8]} color={pal.jacket} z={0.02} ink={[1.0, 1.0]} seed={31} />
        <Flat geo={rect(0.09, 0.07)} pos={[0.12, 0.69]} color={pal.pants} z={0.03} ink={[1.2, 1.25]} seed={32} />
        {[-1, 1].map((sd, i) => <Flat key={i} geo={poly('col' + sd, [[0, 0], [sd * 0.13, 0.01], [sd * 0.05, -0.12]])} pos={[sd * 0.01, 1.03]} color="#fbf6ea" z={0.04} ink={[1.15, 1.15]} seed={40 + i} />)}
        <Flat geo={poly('tie', [[0, 0.04], [0.035, 0], [0, -0.17], [-0.035, 0]])} pos={[0, 1.0]} color={pal.tie} z={0.05} ink={[1.3, 1.15]} seed={44} />
        <group position={[0, 0, 0.06]}>{arm(-1, aL, 1)}{arm(1, aR, 2)}</group>
        <group position={[0, 1.37, 0.08]} rotation={[0, 0, nod]}>
          <Flat geo={circle(0.3)} color={pal.skin} ink={[1.065, 1.065]} seed={50} />
          <Flat geo={fringe()} color={pal.hair} z={0.01} ink={[1.04, 1.04]} seed={51} />
          {[-1, 1].map((sd, i) => (
            <group key={i} position={[sd * 0.105, -0.01, 0.02]}>
              <mesh geometry={halfDisc(0.04)} material={mm('#2a1f24')} scale={[1, blinkK, 1]} />
              <mesh geometry={rect(0.095, 0.014)} material={inkM} position={[0, 0.003, 0.001]} />
            </group>
          ))}
          <mesh geometry={smile()} material={mm('#8a3f3a')} position={[0, -0.04, 0.02]} />
          {hat && hat.type === 'top' && <group position={[0, 0.27, 0.02]}><Flat geo={rect(0.34, 0.34)} pos={[0, 0.16]} color={hat.color} z={0.02} ink={[1.1, 1.06]} seed={60} /><Flat geo={ellipse(0.27, 0.05)} pos={[0, 0]} color={hat.color} z={0.03} ink={[1.06, 1.3]} seed={61} /><Flat geo={rect(0.34, 0.05)} pos={[0, 0.07]} color="#b83f3a" z={0.035} ink={null} /></group>}
          {hat && hat.type === 'bowler' && <group position={[0, 0.25, 0.02]}><Flat geo={dome(0.22)} pos={[0, 0.0]} color={hat.color} z={0.02} ink={[1.08, 1.08]} seed={62} /><Flat geo={ellipse(0.31, 0.045)} pos={[0, 0]} color={hat.color} z={0.03} ink={[1.05, 1.3]} seed={63} /></group>}
          {hat && hat.type === 'cap' && <group position={[0, 0.2, 0.02]}><Flat geo={dome(0.3)} pos={[0, 0.02]} color={hat.color} z={0.02} ink={[1.05, 1.05]} seed={64} /><Flat geo={ellipse(0.2, 0.04)} pos={[0.2, 0.0]} color={hat.color} z={0.03} ink={[1.08, 1.3]} seed={65} /></group>}
          {pal.glasses && <group position={[0, -0.005, 0.04]}>{[-1, 1].map((sd, i) => <mesh key={i} geometry={ring(0.078, 0.062)} material={inkM} position={[sd * 0.105, 0, 0]} />)}<mesh geometry={rect(0.05, 0.012)} material={inkM} /></group>}
        </group>
      </group>
    </group>
  );
}
