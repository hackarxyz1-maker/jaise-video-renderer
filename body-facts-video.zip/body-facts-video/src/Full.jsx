import React, { useMemo } from 'react';
import * as THREE from 'three';
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { useThree, useFrame } from '@react-three/fiber';
import { FPS, camAt, dipAt } from './camera.js';
import { WORLDS, skyTex, Hall, EyeRoom, TorsoLab, BenchStreet, Lab, Gym, Workshop, CarStreet } from './worlds.jsx';

const SS = 1.5; // supersample factor for the offscreen pass

const POST_FRAG = `
uniform sampler2D tColor; uniform sampler2D tDepth; uniform vec2 texel;
uniform float focus, near, far, dip, scale; varying vec2 vUv;
float lin(float d){ float z = d*2.0-1.0; return 2.0*near*far/(far+near-z*(far-near)); }
float coc(float z){ return min(abs(1.0/z-1.0/focus)*28.0*scale, 14.0*scale); }
void main(){
  float z0 = lin(texture2D(tDepth, vUv).x);
  float c0 = coc(z0);
  vec4 acc = texture2D(tColor, vUv); float ws = 1.0;
  for (int i = 0; i < 24; i++) {
    float fi = float(i) + 1.0;
    float r = sqrt(fi/24.0) * c0, a = fi * 2.39996;
    vec2 uv = vUv + vec2(cos(a), sin(a)) * r * texel;
    float zs = lin(texture2D(tDepth, uv).x);
    float w = zs < z0 ? 1.0 : smoothstep(0.0, 1.0, coc(zs) / max(r, 0.0001));
    acc += texture2D(tColor, uv) * w; ws += w;
  }
  vec3 col = acc.rgb / ws;
  vec2 q = (vUv - 0.5) * vec2(1.0, 0.8);
  col *= mix(1.0, 0.74, smoothstep(0.32, 0.85, length(q)));
  col = mix(col, vec3(0.896, 0.791, 0.578), dip);
  gl_FragColor = vec4(col, 1.0);
  #include <colorspace_fragment>
}`;

function Scene({ t }) {
  const { shot, world, cam, look, focus } = camAt(t);
  const W = WORLDS[world];
  const { gl, scene, camera, size } = useThree();
  const dpr = gl.getPixelRatio();
  const rw = Math.round(size.width * dpr * SS), rh = Math.round(size.height * dpr * SS);

  const key = useMemo(() => {
    const l = new THREE.DirectionalLight('#ffffff', 2); l.castShadow = true;
    l.shadow.mapSize.set(1024, 1024);
    Object.assign(l.shadow.camera, { left: -10, right: 10, top: 10, bottom: -10, near: 1, far: 50 });
    l.shadow.bias = -0.0004; l.shadow.normalBias = 0.03; return l;
  }, []);
  const sky = useMemo(() => new THREE.Mesh(new THREE.SphereGeometry(100, 24, 16), new THREE.MeshBasicMaterial({ side: THREE.BackSide, fog: false, depthWrite: false })), []);
  const post = useMemo(() => {
    const depthTexture = new THREE.DepthTexture(rw, rh); depthTexture.type = THREE.UnsignedIntType;
    depthTexture.minFilter = depthTexture.magFilter = THREE.NearestFilter;
    const rt = new THREE.WebGLRenderTarget(rw, rh, { depthBuffer: true, depthTexture, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter });
    const mat = new THREE.ShaderMaterial({
      uniforms: { tColor: { value: rt.texture }, tDepth: { value: depthTexture }, texel: { value: new THREE.Vector2(1 / rw, 1 / rh) }, focus: { value: 5 }, near: { value: 0.3 }, far: { value: 120 }, dip: { value: 0 }, scale: { value: rw / 1080 } },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
      fragmentShader: POST_FRAG, depthTest: false, depthWrite: false,
    });
    const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), mat); quad.frustumCulled = false;
    const sc = new THREE.Scene(); sc.add(quad);
    return { rt, mat, sc, cam: new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1) };
  }, [rw, rh]);

  useFrame(() => {
    camera.position.set(cam[0], cam[1], cam[2]); camera.lookAt(look[0], look[1], look[2]); camera.updateMatrixWorld();
    sky.position.copy(camera.position); sky.material.map = skyTex(W); sky.material.needsUpdate = true;
    key.color.set(W.key); key.intensity = W.ki;
    key.position.set(look[0] - 7, look[1] + 10, look[2] + 6); key.target.position.set(look[0], look[1], look[2]); key.target.updateMatrixWorld();
  }, 0);

  useFrame(() => {
    post.mat.uniforms.focus.value = focus; post.mat.uniforms.dip.value = dipAt(t);
    gl.setRenderTarget(post.rt); gl.clear(); gl.render(scene, camera);
    gl.setRenderTarget(null); gl.clear(); gl.render(post.sc, post.cam);
  }, 1);

  const p = { t, cam };
  return (
    <>
      <color attach="background" args={[W.fog[0]]} />
      <fog attach="fog" args={[W.fog[0], W.fog[1], W.fog[2]]} />
      <hemisphereLight args={[W.hemi[0], W.hemi[1], W.hemi[2]]} />
      <primitive object={key} /><primitive object={key.target} />
      <primitive object={sky} renderOrder={-1} />
      {world === 0 && <Hall {...p} s9={shot === 8} />}
      {world === 1 && <EyeRoom {...p} />}
      {world === 2 && <TorsoLab {...p} />}
      {world === 3 && <BenchStreet {...p} />}
      {world === 4 && <Lab {...p} />}
      {world === 5 && <Gym {...p} />}
      {world === 6 && <Workshop {...p} />}
      {world === 7 && <CarStreet {...p} />}
    </>
  );
}

export const Full = () => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  return (
    <AbsoluteFill style={{ background: '#f3e6c8' }}>
      <ThreeCanvas width={width} height={height} shadows camera={{ fov: 80, near: 0.3, far: 120, position: [0, 2, 5] }} gl={{ antialias: false }}>
        <Scene t={frame / FPS} />
      </ThreeCanvas>
    </AbsoluteFill>
  );
};
