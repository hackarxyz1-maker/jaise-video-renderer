import React from 'react';
import * as THREE from 'three';
import {toCreasedNormals} from 'three/examples/jsm/utils/BufferGeometryUtils.js';

export const INK = '#351f22';
export const CREAM = '#f3e6c8';
export const rng = (s) => () => (s = (s * 16807) % 2147483647) / 2147483647;
export const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const ease = (x) => { x = clamp(x); return x * x * (3 - 2 * x); };
export const easeOutBack = (x) => { x = clamp(x); const c = 1.9; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); };

// ---------- geometry cache ----------
const gc = {};
const memo = (k, f) => gc[k] || (gc[k] = f());
export const G = {
  box: (w, h, d) => memo(`b${w},${h},${d}`, () => new THREE.BoxGeometry(w, h, d)),
  cyl: (rt, rb, h, s = 24) => memo(`c${rt},${rb},${h},${s}`, () => new THREE.CylinderGeometry(rt, rb, h, s)),
  sph: (r, w = 24, h = 16) => memo(`s${r},${w},${h}`, () => new THREE.SphereGeometry(r, w, h)),
  ico: (r, d = 1) => memo(`i${r},${d}`, () => new THREE.IcosahedronGeometry(r, d)),
  cone: (r, h, s = 20) => memo(`k${r},${h},${s}`, () => new THREE.ConeGeometry(r, h, s)),
  tor: (r, t, a = Math.PI * 2) => memo(`t${r},${t},${a}`, () => new THREE.TorusGeometry(r, t, 10, 36, a)),
  knot: (r, t) => memo(`n${r},${t}`, () => new THREE.TorusKnotGeometry(r, t, 90, 10, 2, 3)),
  cap: (r, l) => memo(`p${r},${l}`, () => new THREE.CapsuleGeometry(r, l, 4, 10)),
};

// ---------- painted flat-colour textures with wear ----------
const texCache = {};
function paint(base, { seed = 1, wear = 1, plank = 0, brick = 0, tile = 0 } = {}) {
  const key = JSON.stringify([base, seed, wear, plank, brick, tile]);
  if (texCache[key]) return texCache[key];
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = base; g.fillRect(0, 0, 256, 256);
  const r = rng(seed * 7919 + 13);
  if (plank) {
    const h = 256 / plank;
    for (let i = 0; i < plank; i++) {
      g.fillStyle = `rgba(255,235,200,${0.04 + r() * 0.08})`; g.fillRect(0, i * h, 256, h);
      g.fillStyle = 'rgba(40,22,24,.45)'; g.fillRect(0, i * h, 256, 3);
      const x = r() * 256; g.fillRect(x, i * h, 3, h);
    }
  }
  if (brick) {
    const h = 256 / brick;
    for (let j = 0; j < brick; j++) {
      g.fillStyle = 'rgba(40,22,24,.5)'; g.fillRect(0, j * h, 256, 3);
      const w = 256 / 4, off = (j % 2) * w / 2;
      for (let i = -1; i < 5; i++) {
        g.fillRect(i * w + off, j * h, 3, h);
        g.fillStyle = `rgba(${r() > 0.5 ? '255,220,190' : '50,25,20'},${0.05 + r() * 0.1})`;
        g.fillRect(i * w + off + 3, j * h + 3, w - 3, h - 3);
        g.fillStyle = 'rgba(40,22,24,.5)';
      }
    }
  }
  if (tile) {
    const h = 256 / tile;
    for (let i = 0; i <= tile; i++) { g.fillStyle = 'rgba(40,22,24,.35)'; g.fillRect(i * h, 0, 2, 256); g.fillRect(0, i * h, 256, 2); }
  }
  for (let i = 0; i < wear * 14; i++) { // stains
    g.fillStyle = r() > 0.55 ? `rgba(255,240,210,${0.06 + r() * 0.1})` : `rgba(40,25,25,${0.06 + r() * 0.1})`;
    g.beginPath(); g.ellipse(r() * 256, r() * 256, 6 + r() * 30, 3 + r() * 14, r() * 3, 0, 6.28); g.fill();
  }
  g.strokeStyle = 'rgba(40,25,25,.35)'; g.lineWidth = 1.5; // scratches
  for (let i = 0; i < wear * 8; i++) { const x = r() * 256, y = r() * 256; g.beginPath(); g.moveTo(x, y); g.lineTo(x + (r() - .5) * 40, y + (r() - .5) * 40); g.stroke(); }
  g.fillStyle = 'rgba(255,245,220,.5)'; // chips
  for (let i = 0; i < wear * 6; i++) g.fillRect(r() * 256, r() * 256, 2 + r() * 4, 2 + r() * 3);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace;
  return (texCache[key] = t);
}

const band = new THREE.DataTexture(new Uint8Array([85, 175, 255]), 3, 1, THREE.RedFormat);
band.minFilter = band.magFilter = THREE.NearestFilter; band.needsUpdate = true;

const mc = {};
export function mat(base, o = {}) {
  const key = base + JSON.stringify(o);
  if (mc[key]) return mc[key];
  let map = paint(base, o);
  if (o.rep) { map = map.clone(); map.repeat.set(o.rep[0], o.rep[1]); map.needsUpdate = true; }
  const m = new THREE.MeshToonMaterial({ color: '#ffffff', map, gradientMap: band });
  if (o.glow) { m.emissive = new THREE.Color(o.glow); m.emissiveIntensity = o.gi ?? 0.9; }
  if (o.opacity) { m.transparent = true; m.opacity = o.opacity; m.depthWrite = false; }
  return (mc[key] = m);
}
export const basic = (() => { const c = {}; return (col, o = {}) => c[col + JSON.stringify(o)] || (c[col + JSON.stringify(o)] = new THREE.MeshBasicMaterial({ color: col, fog: false, ...o })); })();

// ---------- outlined solid (inverted hull + crease edge lines) ----------
const hullCache = new WeakMap(), edgeCache = new WeakMap(), hullMats = {};
function hullGeo(g) {
  if (!hullCache.has(g)) { const h = toCreasedNormals(g.index ? g.toNonIndexed() : g.clone(), Math.PI); hullCache.set(g, h); }
  return hullCache.get(g);
}
function hullMat(th) {
  const k = th.toFixed(4);
  return hullMats[k] || (hullMats[k] = new THREE.ShaderMaterial({
    uniforms: { thick: { value: th } }, side: THREE.BackSide,
    vertexShader: 'uniform float thick; void main(){ gl_Position = projectionMatrix*modelViewMatrix*vec4(position+normalize(normal)*thick,1.0); }',
    fragmentShader: 'void main(){ gl_FragColor = vec4(0.0356,0.0137,0.0160,1.0); }',
  }));
}
const edgeMat = new THREE.LineBasicMaterial({ color: INK, fog: false });
function edgeGeo(g) { if (!edgeCache.has(g)) edgeCache.set(g, new THREE.EdgesGeometry(g, 35)); return edgeCache.get(g); }

export function Solid({ geo, m, pos, rot, scale = 1, ink = 0.03, edges = false, cast = true, recv = true, children }) {
  const s = Array.isArray(scale) ? scale : [scale, scale, scale];
  const th = ink / ((s[0] + s[1] + s[2]) / 3);
  return (
    <group position={pos} rotation={rot} scale={s}>
      <mesh geometry={geo} material={m} castShadow={cast} receiveShadow={recv} />
      {ink > 0 && <mesh geometry={hullGeo(geo)} material={hullMat(th)} />}
      {edges && <lineSegments geometry={edgeGeo(geo)} material={edgeMat} />}
      {children}
    </group>
  );
}

// ---------- in-world painted signs ----------
const labCache = {};
export function labelTex(lines, { w = 512, h = 192, bg = '#d6a436', fg = INK, stripes = false } = {}) {
  const key = JSON.stringify([lines, w, h, bg, fg, stripes]);
  if (labCache[key]) return labCache[key];
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d');
  g.fillStyle = bg; g.fillRect(0, 0, w, h);
  const r = rng(5);
  for (let i = 0; i < 16; i++) { g.fillStyle = `rgba(40,25,25,${0.05 + r() * 0.07})`; g.beginPath(); g.ellipse(r() * w, r() * h, 10 + r() * 40, 4 + r() * 14, r() * 3, 0, 6.28); g.fill(); }
  if (stripes) { g.fillStyle = 'rgba(40,25,25,.85)'; for (let x = -h; x < w + h; x += 46) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x + 22, 0); g.lineTo(x + 22 - h * 0.4, 18); g.lineTo(x - h * 0.4, 18); g.fill(); g.beginPath(); g.moveTo(x, h); g.lineTo(x + 22, h); g.lineTo(x + 22 + h * 0.4, h - 18); g.lineTo(x + h * 0.4, h - 18); g.fill(); } }
  g.strokeStyle = INK; g.lineWidth = 8; g.strokeRect(4, 4, w - 8, h - 8);
  g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle';
  const items = lines.map((l) => (typeof l === 'string' ? [l, 0] : l));
  const total = items.length;
  items.forEach(([txt, sz], i) => {
    const size = sz || Math.min(h / (total + 0.6), w * 0.9 / (txt.length * 0.7));
    g.font = `bold ${size}px Georgia, "DejaVu Serif", serif`;
    g.fillText(txt, w / 2, (h / (total + 1)) * (i + 1) + (total === 1 ? 0 : 2));
  });
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return (labCache[key] = t);
}
const signMats = {};
export function Sign({ pos, rot, size = [1.6, 0.6], lines, bg, fg, stripes, s = 1, w = 512, h }) {
  const hh = h || Math.round(w * size[1] / size[0]);
  const key = JSON.stringify([lines, bg, fg, stripes, w, hh]);
  const m = signMats[key] || (signMats[key] = new THREE.MeshBasicMaterial({ map: labelTex(lines, { w, h: hh, bg, fg, stripes }), color: '#f0e8dc' }));
  return (
    <group position={pos} rotation={rot} scale={s}>
      <Solid geo={G.box(size[0] + 0.12, size[1] + 0.12, 0.07)} m={mat('#5e3b2b', { seed: 3 })} ink={0.02} />
      <mesh position={[0, 0, 0.04]}><planeGeometry args={size} /><primitive object={m} attach="material" /></mesh>
    </group>
  );
}

// ---------- facade: extruded wall with window reveals, door notch, sills, awning, cornice ----------
const facCache = {};
export function Facade({ w = 8, h = 6.5, d = 0.6, pos, rot, wins = [], door, wall = '#b5573f', trim = '#ead9b5', seed = 1, brickRows = 0, lit = '#ffd98a' }) {
  const key = JSON.stringify([w, h, d, wins, door]);
  if (!facCache[key]) {
    const sh = new THREE.Shape();
    sh.moveTo(-w / 2, 0);
    if (door) { sh.lineTo(door.x - door.w / 2, 0); sh.lineTo(door.x - door.w / 2, door.h); sh.lineTo(door.x + door.w / 2, door.h); sh.lineTo(door.x + door.w / 2, 0); }
    sh.lineTo(w / 2, 0); sh.lineTo(w / 2, h); sh.lineTo(-w / 2, h); sh.lineTo(-w / 2, 0);
    wins.forEach((v) => { const p = new THREE.Path(); p.moveTo(v.x - v.w / 2, v.y); p.lineTo(v.x - v.w / 2, v.y + v.h); p.lineTo(v.x + v.w / 2, v.y + v.h); p.lineTo(v.x + v.w / 2, v.y); p.lineTo(v.x - v.w / 2, v.y); sh.holes.push(p); });
    const g = new THREE.ExtrudeGeometry(sh, { depth: d, bevelEnabled: false });
    g.translate(0, 0, -d / 2);
    const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) / 4, uv.getY(i) / 4);
    facCache[key] = g;
  }
  const wm = mat(wall, { seed, wear: 1.4, brick: brickRows, rep: [2, 2] });
  return (
    <group position={pos} rotation={rot}>
      <Solid geo={facCache[key]} m={wm} ink={0.035} edges />
      <mesh position={[0, h / 2, -d / 2 + 0.02]}><planeGeometry args={[w - 0.02, h]} /><primitive object={basic(lit)} attach="material" /></mesh>
      {wins.map((v, i) => (
        <group key={i}>
          <Solid geo={G.box(v.w + 0.3, 0.1, d * 0.7)} m={mat(trim, { seed: 4 })} pos={[v.x, v.y - 0.04, d * 0.3]} ink={0.02} />
          <Solid geo={G.box(0.06, v.h, 0.05)} m={mat(trim)} pos={[v.x, v.y + v.h / 2, -d / 2 + 0.06]} ink={0.012} cast={false} />
          <Solid geo={G.box(v.w, 0.06, 0.05)} m={mat(trim)} pos={[v.x, v.y + v.h * 0.55, -d / 2 + 0.06]} ink={0.012} cast={false} />
        </group>
      ))}
      {door && (
        <group>
          <Solid geo={G.box(door.w - 0.12, door.h - 0.06, 0.1)} m={mat('#6b4330', { seed: 8, plank: 6 })} pos={[door.x, door.h / 2, -d / 2 + 0.1]} ink={0.02} />
          <Solid geo={G.sph(0.05)} m={mat('#d6a436')} pos={[door.x + door.w * 0.28, door.h * 0.45, -d / 2 + 0.2]} ink={0.012} />
          <Solid geo={G.box(door.w + 0.7, 0.12, 0.9)} m={mat('#b83f3a', { seed: 9 })} pos={[door.x, door.h + 0.28, d / 2 + 0.3]} rot={[0.22, 0, 0]} ink={0.025} />
        </group>
      )}
      <Solid geo={G.box(w + 0.3, 0.26, d + 0.3)} m={mat(trim, { seed: 6 })} pos={[0, h + 0.1, 0]} ink={0.03} />
    </group>
  );
}

// ---------- room shell ----------
export function Room({ ox = 0, zc = 0, w = 16, d = 16, h = 7, floor, wall, ceil, back = true }) {
  return (
    <group position={[ox, 0, zc]}>
      <Solid geo={G.box(w, 0.2, d)} m={floor} pos={[0, -0.1, 0]} ink={0} />
      <Solid geo={G.box(w, 0.3, d)} m={ceil} pos={[0, h + 0.15, 0]} ink={0} cast={false} />
      {back && <Solid geo={G.box(w, h, 0.3)} m={wall} pos={[0, h / 2, -d / 2]} ink={0} />}
      <Solid geo={G.box(0.3, h, d)} m={wall} pos={[-w / 2, h / 2, 0]} ink={0} />
      <Solid geo={G.box(0.3, h, d)} m={wall} pos={[w / 2, h / 2, 0]} ink={0} />
      <Solid geo={G.box(w, h, 0.3)} m={wall} pos={[0, h / 2, d / 2 + 0.6]} ink={0} cast={false} />
    </group>
  );
}

export function Barrel({ pos, s = 1 }) {
  return (
    <group position={pos} scale={s}>
      <Solid geo={G.cyl(0.46, 0.4, 1.0)} m={mat('#8a5a3c', { seed: 11, plank: 7 })} pos={[0, 0.5, 0]} ink={0.03} />
      {[0.2, 0.8].map((y) => <Solid key={y} geo={G.cyl(0.475, 0.44, 0.07)} m={mat('#3b3b46')} pos={[0, y, 0]} ink={0.015} />)}
    </group>
  );
}
export function Crate({ pos, s = 1, rot, label }) {
  return (
    <group position={pos} rotation={rot} scale={s}>
      <Solid geo={G.box(0.9, 0.7, 0.7)} m={mat('#b58b55', { seed: 12, plank: 5 })} pos={[0, 0.35, 0]} ink={0.03} edges />
      {label && <mesh position={[0, 0.37, 0.355]}><planeGeometry args={[0.7, 0.28]} /><primitive object={new THREE.MeshBasicMaterial({ map: labelTex([label], { w: 256, h: 100, bg: '#e8d8b0' }) })} attach="material" /></mesh>}
    </group>
  );
}
export function Lamp({ pos, t = 0, light = true }) {
  return (
    <group position={pos}>
      <Solid geo={G.cyl(0.07, 0.1, 3.6, 12)} m={mat('#2f3a3a', { seed: 14 })} pos={[0, 1.8, 0]} ink={0.025} />
      <Solid geo={G.box(0.5, 0.6, 0.5)} m={mat('#ffd98a', { glow: '#ffcf6a', gi: 1.2 })} pos={[0, 3.8, 0]} ink={0.03} />
      <Solid geo={G.cone(0.42, 0.3)} m={mat('#2f3a3a')} pos={[0, 4.25, 0]} ink={0.02} />
      {light && <pointLight position={[0, 3.6, 0.6]} intensity={22} distance={11} color="#ffc872" />}
    </group>
  );
}
export function Cobble({ ox = 0, w = 40, d = 22, zc = -2 }) {
  return (
    <group position={[ox, 0, zc]}>
      <Solid geo={G.box(w, 0.2, d)} m={mat('#5d5560', { seed: 21, wear: 2, tile: 8, rep: [10, 5] })} pos={[0, -0.1, 0]} ink={0} />
      <Solid geo={G.box(w, 0.16, 3.4)} m={mat('#8a7566', { seed: 22, plank: 6, rep: [12, 1] })} pos={[0, 0.02, -2.2 - zc]} ink={0} />
    </group>
  );
}
