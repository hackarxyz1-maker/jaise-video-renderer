cd /d "%~dp0"
if not exist node_modules call npm install
call npx remotion render src/index.jsx BodyFacts out\test.mp4 --gl=angle --frames=0-29 --image-format=jpeg --jpeg-quality=92 --crf=17
pause
